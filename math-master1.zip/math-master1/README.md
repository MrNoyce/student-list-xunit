# math-master
A simple math library.
