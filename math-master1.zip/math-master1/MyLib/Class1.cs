﻿using System;

namespace MyLib
{
    public class Class1
    {
    }
}
