﻿using System;

namespace myLib
{
    public class MathHelper
    {
        public int Max(int x, int y) 
        {
            if(x == 0 && y == 0)
            {
                return 0;
            }
            throw new NotImplementedException("Write tests here");
        }
    }
}
